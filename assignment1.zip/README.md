# LAB1-DV2599

If you can't run the code due to incompatible or lacking modules please use the `environment.yml` with miniconda or alike virtual environment managers. (The docker component is experimental and may not work.)

The code consists of two parts: an interactive python notebook (ran in jupyter lab) and a python-file containing an object-oriented implementation of the concept learning algorithm. Please run the notebook first and after an initial skim check  `concept_learner.py`.